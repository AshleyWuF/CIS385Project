class Catalog
{
	constructor()
	{
		this.products=
		[
			{id:1,name:"AHC MASTERS",  code:"ahcsunstick",	 image:"AHC.jpg",	
			description:"AHC Masters Air Rich Sun Stick SPF 50+ Large Size (22g)."	 ,				price:23.86},

			{id:2,name:"ABIB AIRY", code:"abibsunstick", image:"Abib.jpg"	,
			description:"Abib Airy Sunstick Water Resistant Smoothing Bar SPF 50+ (23g)."	,			price:25.90},

			{id:3,name:"ISNTREE SUNSCREEN",  code:"isntreesungel",	 image:"Isntree.jpg",	
			description:"Isntree Hyaluronic Acid Watery Sun Gel SPF 50+ (50mL)."		,				price:18.30},

			{id:4,name:"HARUHARU WONDER",  code:"haruharusunscreen",	 image:"Haruharu.jpg",	
			description:"Haruharu Wonder Black Rice Pure Mineral Relief Dairy Sunscreen SPF 50+ (50mL).", price:11.07},

			{id:5,name:"TOCOBO COTTON",  code:"tocobosunstick",	 image:"Tocobo.jpg",	
			description:"Tocobo Cotton Soft Sun Stick SPF 50+ (19g)."		,							price:29.00},
		];
	}
	getItem(code)
	{
		 for (let i=0; i<this.products.length; i+=1)
		 {
			 if(this.products[i].code==code) return this.products[i];
		 } 
		 return null;
	}
	findItem(code)
	{
		for (let i=0; i<this.products.length; i+=1)
		{
			 if(this.products[i].code==code) return true;
		} 
		 return false;
	}
	getProducts()
	{
		return this.products;
	}
}
