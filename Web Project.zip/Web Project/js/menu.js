let flag=getCookie("flag");
if(flag =="true") document.writeln("<td width='100' align=center><a href='logoff.html'>Logoff</a></td>");
else document.writeln("<td width='100' align=center><a href='login.html'>Login</a></td>");	
document.writeln("<td width='100' align=center><a href='about.html'>About</a></td>");  
document.writeln("<td width='100' align=center><a href='products.html'>Product List</a></td>");	
document.writeln("<td width='100' align=center><a href='contact.html'>Contact Us</a></td>");
